/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Constants;

/**
 *
 * @author Admin
 */
public class INFO_CONSTANTS {
    public final static byte INS_THONGTIN = (byte) 0x02;
    public final static byte INS_NAPANH = (byte) 0x03;
    public final static byte INS_ANH = (byte) 0x00;
    public final static byte INS_INSERT = (byte) 0x01;
    public final static byte INS_CHANGE_INFO= (byte)0x03;
    public final static byte INS_CHANGE_IMAGE = (byte)0x04;
    
    public final static byte INS_BLOCK = (byte)0x07;
    public final static byte INS_UNBLOCK = (byte)0x08;
    public final static byte INS_ERROR = (byte)0x09;
    public final static byte INS_CHECKBLOCKE = (byte)0xA0;
    public final static byte INS_CHECKERROR = (byte)0x0A1;
    
    
    public final static short GET_ID=0;
    public final static short GET_HOTEN=1;
    public final static short GET_NGAYSINH=2;
    public final static short GET_GIOITINH=3;
    public final static short GET_SDT=4;
    public final static short GET_CMND=5;
    public final static short GET_DIACHI=6;
     public final static short COUNT_ID=0;
     public final static short COUNT_HOTEN=1;
    public final static short COUNT_NGAYSINH=2;
    public final static short COUNT_GIOITINH=3;
    public final static short COUNT_SDT=4;
    public final static short COUNT_CMND=5;
    public final static short COUNT_DIACHI=6;
      public final static short COUNT_AVATAR=7;
}
