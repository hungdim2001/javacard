/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Constants;

/**
 *
 * @author Admin
 */
public class MARKET_CONSTANTS {
    public final static byte INS_THONGTIN = (byte) 0x00;
    public final static byte INS_SHOW_MONEY = (byte) 0x03;
    public final static byte INS_NAPTIEN = (byte) 0x01;
    public final static byte INS_THANHTOAN = (byte) 0x02;
   
}
