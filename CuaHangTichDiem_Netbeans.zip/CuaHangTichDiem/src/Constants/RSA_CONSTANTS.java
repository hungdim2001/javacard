/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Constants;

/**
 *
 * @author Admin
 */
public interface RSA_CONSTANTS {
    public static final byte INS_GET_PUB_MODULUS= (byte)0x00;
    public static final byte INS_GET_PUB_EXPONENT= (byte)0x01;
    public static final byte INS_SIGN= (byte)0x02;
}
