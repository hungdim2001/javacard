package auth;
public interface SUPERMARKET_CONSTANTS {

	final static byte INS_SHOW = (byte)0x00;
	final static byte INS_NAPTIEN = (byte)0x01;
	final static byte INS_THANHTOAN = (byte)0x02;
	
	final static short SW_LACK_MONEY = 0x6699;
	final static byte PARAMETER_INTERFACE = 0x11;
}
